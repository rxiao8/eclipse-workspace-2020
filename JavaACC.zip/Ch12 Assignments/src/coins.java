
public class coins {
	private String name;
	private double value;
	private int quantity;
	private double totalAmount;
	
	public void getValue() {
		//totalAmount
	}

}
