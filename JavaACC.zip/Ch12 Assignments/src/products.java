
public class products {
	private String name;
	private double cost;
	private int quantity;
	
	public void printName() {
		//get name
	}
	
	public void printCost() {
		//get cost
	}
	
	public void setQuantity() {
		
	}
}
