
public class operator {
	private double profit;
	private products restock;
	
	public void removeCoins() {
		//takes out money
	}
	
	public void restocking() {
		//takes unstocked list and restocks the machine
	}
}
