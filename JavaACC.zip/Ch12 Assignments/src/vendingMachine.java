import java.util.ArrayList;

public class vendingMachine {
	private ArrayList<String> products;
	private double totalCost;
	private int inputCoins;
	private int change;
	private coins startingAmount;
	private coins remainingAmount;
	
	public vendingMachine(coins totalAmount , products quanitity ) {
		
	}
	
	public void menu() {
		//print out the list of products and their prices
	}
	
	public void selection() {
		//selection is made and total is computed
	}
	
	public void errors() {
		//user input is insufficient or out of stock products
	}
	
	public void updateMenu() {
		//updates menu and the amount of coins in system
	}
	
	public void restocked() {
		//prints a list of unstocked products
	}
	
	public void earnedCoins() {
		//remainingCoing 
	}
	
	

}
