
public class user {
	private coins totalAmount;
	
	public void findMenu() {
		//prints out a menu
	}
	
	public void selects() {
		//selects a drink
	}
	
	public void insertCoins() {
		//attempt to purchase
	}
	
	public void amountLeft() {
		//coins leftover
	}

}
