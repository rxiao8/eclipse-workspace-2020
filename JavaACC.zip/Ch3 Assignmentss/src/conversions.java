//Rose X.
//September 2020
/** Write a unit conversion program that asks user the amount
 * they would like to change, the unit they want to convert from and to.
 * Reject any incompatible conversions 
 */

import java.util.Scanner;

public class conversions {
	
	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		
		System.out.print("Enter your measurement values: ");
		double measurement = in.nextDouble();
		
		System.out.print("Enter the unit you are converting from (no spaces): ");
		String fromUnit = in.next().toLowerCase();
		
		System.out.print("Enter the unit you want to convert to: ");
		String toUnit = in.next().toLowerCase();
	
		
		final double ML_per_FlOz = 29.5735; 	//Milliliters per Fl_Oz
		final double L_per_FlOz = 0.0295735; 	//Liters per Fl_Oz
		
		final double ML_per_GAL = 3785.41; 		
		final double L_per_GAL = 3.78541; 		
		
		
		
		final double G_per_OZ = 28.3495; 		//Grams per ounce
		final double KG_per_OZ = 0.0283495; 	//Kilograms per ounce
		
		final double G_per_LB = 453.592;		
		final double KG_per_LB = 0.453592;		
		
		
		
		final double MM_per_IN = 25.4;			//Millimeter per inch
		final double CM_per_IN = 2.54;			//Centimeters per inch
		final double M_per_IN = 0.0254;			//Meters per inch
		final double KM_per_IN = 2.54E-5;		//Kilometers per inch
		
		final double MM_per_FT = 304.8;
		final double CM_per_FT = 30.48;
		final double M_per_FT = 0.3048;
		final double KM_per_FT = 3.048E-4;
		
		final double MM_per_MI = 1.609E6;
		final double CM_per_MI = 160934;
		final double M_per_MI = 1609.34;
		final double KM_per_MI = 1.60934;
		
		
		
		double newMeasurement = 0;
		
		
		switch (fromUnit) {
		case "floz":
			switch (toUnit) {
			case "ml":
				newMeasurement = measurement * ML_per_FlOz;
				System.out.printf("%-3s%10.3f %n", "mL:", newMeasurement);
				break;
			case "l":
				newMeasurement = measurement * L_per_FlOz;
				System.out.printf("%-3s%10.3f %n", "L:", newMeasurement);
				break;
			default:
				System.out.print("Incompatible conversions. Please try again.");
			}
			break;
			
			
		case "gal":
			switch (toUnit) {
			case "ml":
				newMeasurement = measurement * ML_per_GAL;
				System.out.printf("mL: %10.3f %n", newMeasurement);
				break;
			case "l":
				newMeasurement = measurement * L_per_GAL;
				System.out.printf("L: %10.3f %n", newMeasurement);
				break;
			default:
				System.out.print("Incompatible conversions. Please try again.");
			}
			break;
			
			
		case "oz":
			switch (toUnit) {
			case "g":
				newMeasurement = measurement * G_per_OZ;
				System.out.printf("g: %10.3f %n", newMeasurement);
				break;
			case "kg":
				newMeasurement = measurement * KG_per_OZ;
				System.out.printf("kg: %10.3f %n", newMeasurement);
				break;
			default:
				System.out.print("Incompatible conversions. Please try again.");
			}
			break;
			
			
		case "lb":
			switch (toUnit) {
			case "g":
				newMeasurement = measurement * G_per_LB;
				System.out.printf("g: %10.3f %n", newMeasurement);
				break;
			case "kg":
				newMeasurement = measurement * KG_per_LB;
				System.out.printf("kg: %10.3f %n", newMeasurement);
				break;
			default:
				System.out.print("Incompatible conversions. Please try again.");
			}
			break;
			
			
		case "in":
			switch (toUnit) {
			case "mm":
				newMeasurement = measurement * MM_per_IN;
				System.out.printf("mm: %10.3f %n", newMeasurement);
				break;
			case "cm":
				newMeasurement = measurement * CM_per_IN;
				System.out.printf("cm: %10.3f %n", newMeasurement);
				break;
			case "m":
				newMeasurement = measurement * M_per_IN;
				System.out.printf("m: %10.3f %n", newMeasurement);
				break;
			case "km":
				newMeasurement = measurement * KM_per_IN;
				System.out.printf("km: %10.3f %n", newMeasurement);
				break;
			default:
				System.out.print("Incompatible conversions. Please try again.");
			}
			break;
			
			
		case "ft":
			switch (toUnit) {
			case "mm":
				newMeasurement = measurement * MM_per_FT;
				System.out.printf("mm: %10.3f %n", newMeasurement);
				break;
			case "cm":
				newMeasurement = measurement * CM_per_FT;
				System.out.printf("cm: %10.3f %n", newMeasurement);
				break;
			case "m":
				newMeasurement = measurement * M_per_FT;
				System.out.printf("m: %10.3f %n", newMeasurement);
				break;
			case "km":
				newMeasurement = measurement * KM_per_FT;
				System.out.printf("km: %10.3f %n", newMeasurement);
				break;
			default:
				System.out.print("Incompatible conversions. Please try again.");
			}
			break;
			
			
		case "mi":
			switch (toUnit) {
			case "mm":
				newMeasurement = measurement * MM_per_MI;
				System.out.printf("mm: %10.3f %n", newMeasurement);
				break;
			case "cm":
				newMeasurement = measurement * CM_per_MI;
				System.out.printf("cm: %10.3f %n", newMeasurement);
				break;
			case "m":
				newMeasurement = measurement * M_per_MI;
				System.out.printf("m: %10.3f %n", newMeasurement);
				break;
			case "km":
				newMeasurement = measurement * KM_per_MI;
				System.out.printf("km: %10.3f %n", newMeasurement);
				break;
			default:
				System.out.print("Incompatible conversions. Please try again.");
			}
			break;
			
			
		}	
		in.close();
		
	}
}

