//Rose X.
//September 2020
//Take user's input of three words and output them in alphabetical order

import java.util.Scanner;

public class sorting_three_words {

	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		
		System.out.print("Enter a word: ");				//a
		String word_a = in.next().toLowerCase();
		
		System.out.print("Enter a second word: ");	//b
		String word_b = in.next().toLowerCase();
		
		System.out.print("Enter a third word: ");	//c
		String word_c = in.next().toLowerCase();
		
		
		if (word_a.compareTo(word_b) < 0) {							// checking if a < b
			if (word_b.compareTo(word_c) < 0) {						//b < c
				System.out.print(word_a +" "+ word_b +" "+ word_c);
			}
			
			else if (word_c.compareTo(word_a) < 0) {				//c	< a
				System.out.print(word_c +" "+ word_a +" "+ word_b);
			}
			
			else {
				System.out.print(word_a +" "+ word_c +" "+ word_b);
			}
		}
		
		if (word_b.compareTo(word_a) < 0) {							//b	< a
			if (word_a.compareTo(word_c) < 0) {						//a < c
				System.out.print(word_b +" "+ word_a +" "+ word_c);	
			}
			else if (word_c.compareTo(word_b) < 0) {				//c < a
				System.out.print(word_c +" "+ word_b +" "+ word_a);
			}
			else {
				System.out.print(word_b +" "+ word_c +" "+ word_a);
			}
		}
			
		in.close();
		
		
	}

}
