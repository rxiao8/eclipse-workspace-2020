package Step_by_stepProblems;

public class EscapeSequences {

	public static void main(String[] args) {
		// Testing out the different test sequences
		
		/**first one is \r\n to encompass new line for the sentences in console. 
		 * Usually \n or %n works, but for Windows use \r\n.
		 */
		System.out.println("What are incentives? \r\n Incenteives are anything in forms of rewards or punishments that evokes a reaction out of people.\r\n A best example is the discount sign we see in stores; we feel compelled to purchase since the discount rewards us by having us pay less.");
		
		//Second is the tab key and use \t
		
		System.out.println("\t Opportunity cost is the value of our second best alternative we gave up during decision making. \r\nThe cost can come in the value of money, happiness, or time.");
		
		//use double backslashes to have one show in console. I think
		System.out.println("The file will be at C:\\Temp\\Secret\\txt.");
		
		//Use a single backslash to have the compiler understand you want quotes in the strings
		System.out.println("One of the best comment I saw about our education system was that: \r\n\"We should not teach our students WHAT to learn, but rather, HOW to learn.\"");
		
		//Now, let us type a paragraph combining them all!
		System.out.println("\tToday, I learned about comparative and absolute advantages during Microeconomics. The topics are essential when analyzing how countries trade by deciding what to produce and trade. \r\n"
				+ "Let us say we have two countries for simplicity: USA and China. Along with that we shall narrow our goods into two things: cars and boba tea. \r\n"
				+ "The goods have to be different because if they were both fruits or both electronics, then there would not be strong incentives present to trade. \r\n"
				+ "Moving on, what if the USA produces more computers and boba teas than China? Meaning they make more than China does at the same cost to produce them. \r\n"
				+ "This means USA has an absolute advantage since they make more of something. Comparative advantage means to produce a good at a lower opportunity cost."
				+ "\r\nTherefore, just because USA makes more of both items does not means their opportunity cost of making them are low. Let us say China can make boba tea at a lower opportunity cost despite not producing at the highest quantity."
				+ "\r\nThen China has the comparative advantage on the tea. If boba tea is highly seeked out in the USA, then the USA would want to trade with China to receive those tea at a lower cost."
				+ "\r\nThe USA should specialize in computers and China should focus on boba tea, and then the two would trade their products. "
				+ "\r\nTheir goal is to obtain resources without expending more opportunity cost since every choice made requires some thing lost. As the saying goes, \"There is no such thing as free lunch.\". Yah \\(0v0)\\");

	}

}
