package Step_by_stepProblems;

import java.util.Scanner;

/** 
 * this program will print some initials. Yah.
 * */

public class InitialComposer {

	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		//Input names of a couple
		System.out.print("Enter your name: ");
		String first = in.next();
		System.out.print("Enter your last name: ");
		String last = in.next();
		
		//Compute and display the inscription
		
		String initials = first.substring(0,1) + "."+ last.substring(0,1) + ".";
		System.out.println("Here are your initials user: " + initials);
		
		/**Testing the last character method, use the variable name for the part where
		 * the book states "str." 
		 */
		System.out.print("Enter your name: ");		
		String lastLetter = in.next();
		System.out.println(lastLetter.substring(lastLetter.length()-1));

	}

}

