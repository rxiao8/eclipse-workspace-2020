package E1_E10;

//Write a program that displays dimensions of objects in mm converted from inches (for papers)

import java.util.Scanner;

public class E1 {

	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		System.out.print("Enter the length in inches: ");
		String lengthIn = in.next();
		double lengthIN = Double.parseDouble(lengthIn);
		
		System.out.print("Enter the width in inches: ");
		String widthIn = in.next();
		double widthIN = Double.parseDouble(widthIn);
		
		final double conversion = 25.4; //This is how many mm in an in
		double lengthMM = (lengthIN) * conversion;
		double widthMM = (widthIN) * conversion;
		
		System.out.println("Your dimensions in mm are " + lengthMM + " x " + widthMM);
		
				

	}
	

}
