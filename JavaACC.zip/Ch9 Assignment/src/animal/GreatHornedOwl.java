package animal;

/*Rose X.
 *November 2020
 *GreatHornedOwl subclass extending Owls superclass
 */

public class GreatHornedOwl extends Owls {

	public GreatHornedOwl() {
	}
	
	public void setLatinName(String n) { 
		super.setLatinName(n);
	}
	
	public void updateWeight(int pounds) {
		super.updateWeight(pounds);
	}
	
	public void addHabitat(String h) {
		super.addHabitat(h);
	}
	
	public String toString() {
		String name = super.LatinName();
		String place = super.getHabitat();
		return "Crows/" + name +"\r\nWeight(oz): " + super.getWeight() 
				+ "\r\nHabitat: " + place 
				+ "\r\nSounds They Make: Whoo. Hooo. WhooHoo. Who.";
	}
}
