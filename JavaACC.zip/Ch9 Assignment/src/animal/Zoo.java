package animal;

/*Rose X.
 *November 2020
 *A driver class testing all methods in the Owls, GreatHornedOwl, and BarnOwl
 */

import java.util.ArrayList;

public class Zoo {

	public static void main(String[] args) {
		ArrayList<Animal> myAnimals = new ArrayList<Animal>();
		
		Owls birdOne = new Owls();
		birdOne.move("By flying");
		
		GreatHornedOwl h1 = new GreatHornedOwl();
		h1.setLatinName("Bubo Virgiannus");
		h1.updateWeight(51.4);
		h1.addHabitat("Forests and fields");
		
		BarnOwl b1 = new BarnOwl();
		b1.setLatinName("Tyto Alba");
		b1.updateWeight(22.4);
		b1.addHabitat("Grasslands, deserts, and agricultural fields");
		
		myAnimals.add(birdOne);
		myAnimals.add(h1);
		myAnimals.add(b1);

		for(int i = 0; i < myAnimals.size(); i++)
		{
			String j = myAnimals.get(i).toString();
			System.out.println(j + "\r\n");
			
		}

	}

}
