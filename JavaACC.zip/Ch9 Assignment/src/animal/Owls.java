package animal;

/*Rose X.
 *November 2020
 *Implement the Animal interface and create an superclass on a specie.
 */

public class Owls implements Animal {
	private String move;
	private double weight;
	private String habitat;
	private String latinName;
	
public Owls() {
	move = "";
	weight = 0;
	habitat = "";
	latinName = "";
}

public void move(String t) {
	move = t;
}

public double getWeight() {
	return weight;
}

public void updateWeight(double x) {
	weight += x;
}

public void addHabitat(String y) {
	habitat = y;
}

public String getHabitat() {
	return habitat;
}

public void setLatinName(String z) { //see if you could set constructor
	latinName = z;
}

public String LatinName() {
	return latinName;
}

public String toString() {
	String movement = "How They Move: " + move;
	return movement;
	
}
}
