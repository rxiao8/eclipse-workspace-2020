package animal;

/*Rose X.
 *November 2020
 *BarnOwl subclass extending Owls superclass
 */

public class BarnOwl extends Owls{
	
	public BarnOwl() {
	}
	public void setLatinName(String n) { 
		super.setLatinName(n);
	}
	
	public void updateWeight(int pounds) {
		super.updateWeight(pounds);
	}
	
	public void addHabitat(String h) {
		super.addHabitat(h);
	}
	
	public String toString() {
		String name = super.LatinName();
		String place = super.getHabitat();
		return "Owls/" + name + "\r\nWeight(oz): " + super.getWeight()
				+ "\r\nHabitat: " + place 
				+ "\r\nSounds They Make: Inhuman screeching and demonic noises";
	}



}
