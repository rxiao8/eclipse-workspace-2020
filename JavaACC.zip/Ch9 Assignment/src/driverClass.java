/*Rose X.
 * November 2020
 * Create a driver class testing Employee, Manager, and Executive
 */
public class driverClass {

	public static void main(String[] args) {
		Employee one = new Employee();
		one.setValues("Rose", 12000);
		System.out.println(one.getName());
		System.out.println(one.getSalary());
		
		System.out.println("\r\n");
		
		Manager two = new Manager();
		two.setValues("Sarah", 120);
		two.setDept("6");
		System.out.println(two.toString());
		
		System.out.println("\r\n");
		
		Executive three = new Executive();
		three.setValues("Harry", 1500);
		three.setDept("5");
		three.setTitle("Chief Marketing Officer");
		System.out.println(three.toString());
		

	}

}
