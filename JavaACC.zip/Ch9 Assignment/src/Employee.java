/*Rose X.
 * November 2020
 * Make a class Employee with name and salary
 */
public class Employee {
	
	private String name;
	private int salary;
	
public Employee(){
	this.name = "";
	this.salary = 0;
}

public void setValues(String name, int salary) {
	this.name = name;
	this.salary = salary;
}

public String getName() {
	return name;
}

public int getSalary() {
	return salary;
}
}
