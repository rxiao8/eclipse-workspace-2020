/*Rose X.
 * November 2020
 * Make a class Manager extending employee
 */
public class Manager extends Employee{
	
	private String department;
	

public Manager() {
	department = "";
}

public void setDept(String department) {
	this.department = department;
}

public String toString() {
	return "Name: " + super.getName() + 
			"\r\nDepartment: " + department + 
			"\r\nSalary: " + super.getSalary();
	}
}

