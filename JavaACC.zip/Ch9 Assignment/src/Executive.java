/*Rose X.
 * November 2020
 * Make a class Executive extending manager
 */
public class Executive extends Manager {
	
	private String title;
	
public void setTitle(String title) {
	this.title = title;
	
}

public String toString() {
	return super.toString() + "\r\nTitle: " + title;
}
}
