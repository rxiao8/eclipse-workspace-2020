package E11_E18;

public class E18 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
