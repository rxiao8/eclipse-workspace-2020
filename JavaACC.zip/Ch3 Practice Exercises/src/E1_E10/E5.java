package E1_E10;

//Write a program that reads the integers as increasing, decreasing, or neither

import java.util.Scanner;

public class E5 {
	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		
		System.out.print("Enter an integer: ");
		int numA = in.nextInt();	
		
		System.out.print("Enter another integer: ");
		int numB = in.nextInt();
		
		System.out.print("Enter a final integer: ");
		int numC = in.nextInt();
		
		if (numA < numB && numB < numC)
		{
			System.out.print("increasing");
		}
		
		else if (numA > numB && numB > numC)
		{
			System.out.print("decreasing");
		}
		else
		{
			System.out.print("neither");
		}
		
		in.close();
		

		
		
	}
}