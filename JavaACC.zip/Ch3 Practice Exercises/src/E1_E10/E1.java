package E1_E10;

//Write a program that reads an integer and prints whether it is negative, zero, or positive

import java.util.Scanner;

public class E1 {
	public static void main(String[] args) {
	
		Scanner in = new Scanner(System.in);
		
		System.out.print("Enter an integer: ");
		int number = in.nextInt();
		
		if (number > 0)
		{
			System.out.println("Your number is positive.");
		}
		if (number < 0)
		{
			System.out.println("Your number is negative.");

		}
		if (number == 0)
		{
			System.out.println("Your number is zero.");
		}
		
		in.close();
	}
}