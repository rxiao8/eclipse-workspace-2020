package E1_E10;

//Print out the integers

import java.util.Scanner;

public class E3 {
	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		System.out.print("Enter an integer: ");
		int number = in.nextInt();
		
		if (number >= 1E10) 
		{
			System.out.print("You have 11 digits.");
		}
		else if (number >= 1E9) 
		{
			System.out.print("You have 10 digits.");
		}
		else if (number >= 1E8) 
		{
			System.out.print("You have 9 digits.");
		}
		else if (number >= 1E7) 
		{
			System.out.print("You have 8 digits.");
		}
		else if (number >= 1E6) 
		{
			System.out.print("You have 7 digits.");
		}
		else if (number >= 1E5) 
		{
			System.out.print("You have 6 digits.");
		}
		else if (number >= 1E4) 
		{
			System.out.print("You have 5 digits.");
		}
		
		else if (number >= 1E3) 
		{
			System.out.print("You have 4 digits.");
		}
		else if (number >= 1E2) 
		{
			System.out.print("You have 3 digits.");
		}
		else if (number >= 1E1) 
		{
			System.out.print("You have 2 digits.");
		}
		else if (number < 10) 
		{
			System.out.print("You have 1 digits.");
		}
		
		in.close();
	

	}
}