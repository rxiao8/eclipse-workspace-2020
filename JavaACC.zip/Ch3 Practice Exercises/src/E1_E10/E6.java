package E1_E10;

//Write a program that reads the integers as increasing, decreasing, or neither. Strict vs Lenient

import java.util.Scanner;

public class E6 {
	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		
			System.out.print("Enter an integer: ");
			int numA = in.nextInt();	
		
			System.out.print("Enter another integer: ");
			int numB = in.nextInt();
		
			System.out.print("Enter a final integer: ");
			int numC = in.nextInt();
			
			System.out.print("Would you like strict or lenient? Submit your choice in lowercase letter. ");
			String mode = in.next();
			
			String modeOne = "strict";
			String modeTwo = "lenient";
			
			if (mode.equals(modeOne)) {
				if (numA < numB && numB < numC)
				{
					System.out.print("increasing");
				}
				
				else if (numA > numB && numB > numC)
				{
					System.out.print("decreasing");
				}
				else
				{
					System.out.print("neither");
				}				
				
			}
			else if (mode.equals(modeTwo)) {
				if (numA != numB && numB != numC) {
					System.out.print("neither");
				}
				else if (numA < numB && numB < numC) {
					System.out.print("increasing");
				}
				else if (numA < numB && numB == numC) {
						System.out.print("increasing");
				}
				else if (numA == numB && numB < numC) {
					System.out.print("increasing");
				}
				else {
					System.out.print("decreasing");
				}
				
			}

	}
}