package E1_E10;

//Write a program that reads an integer and prints whether it is negative, zero, or positive
public class E9 {
	public static void main(String[] args) {
	

	}
}