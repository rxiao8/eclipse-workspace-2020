package E1_E10;

import java.util.Scanner;

/*A program reading a floaty and printing zero in number is zero. Otherwise, print positive/negative. 
 * Print small for Math.abs <0 and large if Math.abs >1000000
 */

public class E2 {
	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		
		System.out.print("Enter an integer: ");
		double floaty = in.nextDouble();
		double abs_floaty = Math.abs(floaty);
		
		//work on is!
		if (floaty == 0){
			System.out.println("Zero");
		}
		else if (floaty > 0) {
			System.out.println("Positive");
			if (floaty > 1E6) {
				System.out.print("Large");
			}
			else if (floaty < 1) {
				System.out.print("Small");
			}
			else {
				System.out.print("In between");
			}
		}
		
		//Mistakes: I did small vs large first, I lost track of brackets, I did not use Math.abs properly which lead to variable inconsistencies
		else {
			System.out.println("Negative");
			if (abs_floaty > 1E6) {
				System.out.print("Large");
			}
			else if (abs_floaty < 1) {
				System.out.print("Small");
			}
			else {
				System.out.print("In between");
			}
		}
		in.close();

	
	}
}
