package E1_E10;

//Write a program that prints your name in large letters, such as (cue example in the textbook on page 26)

public class E6 {

	public static void main(String[] args) {
		System.out.println("***  ***  ***  ***");
		System.out.println("* *  * *  *    *");
		System.out.println("***  * *  ***  ***");
		System.out.println("**   * *    *  *");
		System.out.println("* *  * *  ***  ***");
		System.out.println("");
		System.out.println("****   ****   ****  ****");
		System.out.println("*   *  *  * *       *");
		System.out.println("*   *  *  *  *      *");
		System.out.println("****   *  *   ****  ****"); //another of my favs!
		System.out.println("**     *  *       * *");
		System.out.println("* *    *  *      *  *");
		System.out.println("*  *   ****  ****   ***");
		
		//will be back, I have to plan this on paper first XD. Aight, I am back ! Yaay! I am going to do another one and attempt to make it more curly, if that makes sense XD
		//Oh, and this is my favorite song in this compilation :) Onward!

	}

}
