package E1_E10;

//Write a program that prints a greeting of your choice, perhaps in a language other than English

public class E1 {
	public static void main(String [] args)
	{
		System.out.println("Kon'nichiwa, watashinonamaeha rōzudesu. Hajimemashite!");
		System.out.println("You are cool, bitch. \r\nLike, I wanna be like you.%nCan we do that?"); //So \r\n works, but not %n
	}
}


