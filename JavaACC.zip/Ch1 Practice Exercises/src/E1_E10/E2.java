package E1_E10;

//Write a program that prints the sum of the first ten positive integers, 1+2+...+10
public class E2 {

	public static void main(String[] args) {
		System.out.println(1 + 2 + 3 + 4 + 5 + 6 + 7 + 8 + 9 + 10 + " is the sum of the series from 1-10.");

	}

}
