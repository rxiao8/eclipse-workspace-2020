package E1_E10;

//Write a program that prints the produce of the first ten positive integers, 1*2*...*10. Use * to indicate multiplication in Java

public class E3 {

	public static void main(String[] args) {
		System.out.println(1 * 2 * 3 * 4 * 5 * 6 * 7 * 8 * 9 * 10);

	}

}
