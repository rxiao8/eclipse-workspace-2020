package E1_E10;

//Write a program that prints the balance of an account after the first, second, and third year. The account has an initial balance of $1,000 and earns 5 % interest per year

public class E4 {

	public static void main(String[] args) {
		System.out.println(1000*1.05 + " is the balance of your account after the first year.");
		System.out.println(1000*1.05*1.05 + " is the balance of your account after the second year.");
		System.out.println(1000*1.05*1.05*1.05 + " is the balance of your account after the third year.");
		
		//I struggled with the syntax in terms of using the parentheses. Definitely keep an eye out on those.
		
	}

}
