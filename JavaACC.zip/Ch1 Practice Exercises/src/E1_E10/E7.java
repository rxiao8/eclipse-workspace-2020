package E1_E10;

//Write a program that prints your name in Morse code, like this: (check example on page 26)

public class E7 {
	public static void main(String [] args)
	{
		System.out.println(".-. --- ... . is my name in Morse code :D. Yes, I know my typing is terrible XD. Working on it.");
	}

}

//R (.-.)
//O (---)
//S (...)
//E (.)