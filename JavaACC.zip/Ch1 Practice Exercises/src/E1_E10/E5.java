package E1_E10;

//Write a program that displays your name inside a box on the screen, like this: [Dave]. Do your best to apporximate lines with characters lines with characters such as | - +

public class E5 {

	public static void main(String[] args) {
		System.out.println("-" + "-" + "-" + "-" + "-" + "-");
		System.out.println("|" + "Rose" + "|");
		System.out.println("-" + "-" + "-" + "-" + "-" + "-");
		
//I guess this is the best I can do for now XD
	}

}
