package E1_E10;

//Write a program that prints a face similar to (but different from) the following: (cue pic in page 26)

public class E8 {
	public static void main(String [] args)
	{
		System.out.println("   _____   ");
		System.out.println("  -------       _________________________");
		System.out.println("//|     |\\");
		System.out.println("|(| O <.|)|   < Hello, my name is Rozie. ");
		System.out.println("|||  ^. |||     _________________________");
		System.out.println("|||. ~  |||");
		System.out.println("|||_____|||");
		//do not put quotation marks within a print statement
	}

}
//alright, be right back. Aight, time to see if I can do this :P