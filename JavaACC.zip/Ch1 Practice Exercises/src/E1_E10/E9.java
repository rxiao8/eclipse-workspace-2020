package E1_E10;

//Write a program that prints an imitation of a Piet Mondrain painting. Use @@ or ::: for colors and - and | for lines

public class E9 {
	public static void main(String [] args)
	{
		System.out.println(" ------- --- -----------");
		System.out.println("|@@@@@@@|$$$|@@@@@@@@@@@|");
		System.out.println(" --- ----------- --- ---");
		System.out.println("|:::|@@@@@@@@@@@|:::|@@@|");
		System.out.println(" ---|@@@@@@@@@@@|---|@@@|");
		System.out.println("|###|@@@@@@@@@@@|&&&|@@@|");
		System.out.println("|###|@@@@@@@@@@@|&&&|---|");
		System.out.println(" --- -----------|&&&|$$$|");
		System.out.println("|::::::|$$$$$$$$|---|$$$|");
		System.out.println(" ------|$$$$$$$$|:::|$$$|");
		System.out.println("|&&|:::|$$$$$$$$|---|$$$|");
		System.out.println(" -- --- ------------ $$$|");
		System.out.println("|@@|&&&|@@@@@@@@@@@@|$$$|");
		System.out.println(" -- --- ------------ ---");
		
	}

}
//Let me plan this out on paper first, be right back. Yay! His paintings are those geometric ones with thick and thin black border lines with primary colors used to fill in the blocks