package E1_E10;

//Write a program that prints a house that looks exactly like the one on page 26

public class E10 {
	public static void main(String [] args)
	{
		System.out.println("   +   ");
		System.out.println("  + +  ");
		System.out.println(" +   + ");
		System.out.println("+-----+");
		System.out.println("| .-. |");
		System.out.println("| | | |");
		System.out.println("+-+-+-+");
	}

}
