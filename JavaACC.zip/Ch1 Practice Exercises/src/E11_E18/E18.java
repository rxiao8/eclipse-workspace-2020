package E11_E18;

//Type in and run the following program. Then modify it to show a different greeting and image.
public class E18 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}

//Different file, on file Test.java