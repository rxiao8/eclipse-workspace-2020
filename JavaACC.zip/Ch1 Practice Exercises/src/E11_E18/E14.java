package E11_E18;

//Write  a program that prints the United States flag, using * and =
public class E14 {

	public static void main(String[] args) {
		System.out.println("* * * * * * ===================================");
		System.out.println(" * * * * *  ===================================");
		System.out.println("* * * * * * ===================================");
		System.out.println(" * * * * *  ===================================");
		System.out.println("* * * * * * ===================================");
		System.out.println(" * * * * *  ===================================");
		System.out.println("* * * * * * ===================================");
		System.out.println(" * * * * *  ===================================");
		System.out.println("* * * * * * ===================================");
		System.out.println("===============================================");
		System.out.println("===============================================");
		System.out.println("===============================================");
		System.out.println("===============================================");
		System.out.println("===============================================");
		System.out.println("===============================================");
		System.out.println("===============================================");
	
	
	
	}

}
