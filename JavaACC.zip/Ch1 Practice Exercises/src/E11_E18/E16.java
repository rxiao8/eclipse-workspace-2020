package E11_E18;

//Type in and run the following program. Then modify it to print "Hello, name!"
public class E16 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
//separate file as well.  On Dialog Viewer 2