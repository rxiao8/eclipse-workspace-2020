package E11_E18;

//Write a program that prints an animal speaking a greeting, similar to the one on page 26

public class E11 {

	public static void main(String[] args) {
		System.out.println("             -----");
		System.out.println(" -----     /      \\");
		System.out.println("|     |   < Hello!|");
		System.out.println("| > < |    \\      /");
		System.out.println("|//O//|--^^  ----");
		System.out.println(" ----- ---");
		
	}

}
