package E11_E18;

//Write a program that prints three items, such as the names of your three best friends or favorite movies, on three separate lines

public class E12 {

	public static void main(String[] args) {
		System.out.println("My favorites animes are:");
		System.out.println("Shingeki no Kyojin");
		System.out.println("Dorohedoro");
		System.out.println("Fullmetal Alchemist: Brotherhood");

	}

}
