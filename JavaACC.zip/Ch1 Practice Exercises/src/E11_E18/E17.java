package E11_E18;

//modify E.16 program to include "My name is Hal" message, "I;m sorry Dave." and replace Dave with the name provided by user

public class E17 {

	public static void main(String[] args) {
		

	}

}
//again, on another file. On Dialog Viewer 3