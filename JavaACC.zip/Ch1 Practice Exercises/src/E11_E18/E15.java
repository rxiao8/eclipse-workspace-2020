package E11_E18;

//Type in and run the following program. Then modify it to show the message "Hello,your name!"

public class E15 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
//I will be doing this on a separate file.  On Dialog Viewer 1
		
	}

}
