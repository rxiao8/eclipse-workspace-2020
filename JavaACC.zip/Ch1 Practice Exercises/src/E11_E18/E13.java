package E11_E18;

//Write a program that prints a poem of your choice. Edgar Allen Poe
public class E13 {

	public static void main(String[] args) {
		System.out.println("GreatHeart and the Brain Drain");
		
		System.out.println(" ");
		
		System.out.println("Comfort me with cabbages.");
		System.out.println("My brain's not screwed in tight.");
		System.out.println("Help me plug my ears in case it");
		System.out.println("Wanders out of sight");
		
		System.out.println(" ");
		
		System.out.println("With a cabbage in my left ear");
		System.out.println("And a corkscrew in my right");
		System.out.println("I forget about ontology");
		System.out.println("And I sleep just fine at night");
		
	}

}


