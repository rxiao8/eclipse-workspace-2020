import javax.swing.JOptionPane;

//Type in the following program on page 26 and print "Hello, your name!"
//For E.16

public class DialogViewer {

	public static void main(String[] args) {
		JOptionPane.showMessageDialog(null, "Hello, Rozie! How are the fall classes going for you? Are you keeping up with the assignments and scheduling to make sure your mental health and physical health is adequate?");
		

	}

}
//So what this does is that the message you want to print out will pop out like a dialog box, very kewl