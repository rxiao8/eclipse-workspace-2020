import javax.swing.JOptionPane;

//For E.17

public class DialogViewer3 {

	public static void main(String[] args) {
		String name = JOptionPane.showInputDialog("What is your name?");
		System.out.println("Hello, Rozie");
		String greetings = JOptionPane.showInputDialog("My name is Hal! What would you like me to do?");
		System.out.println("I'm sorry, Rozie. I'm afraid I can't do that.");
	}

}
