import java.net.URL;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;

//For E.18

public class Test {

	public static void main(String[] args) throws Exception 
	{
		URL imageLocation = new URL(
				"https://i.pinimg.com/564x/39/5e/80/395e801ed89e0710bbc9cde051052a7c.jpg");
		JOptionPane.showMessageDialog(null, "This is Timmothee Chalamet, my celebrity crush <3 \r\nSo far, I have only seen in the beautiful film, Call Me By Your Name. \r\nDefinitely recommend those to check it out!", "Sleepy Timmy",
				JOptionPane.PLAIN_MESSAGE, new ImageIcon(imageLocation));

	}

	//What this does is that it will bring a popup of the image you pasted as well as the message you typed next to it
}
//https://i.pinimg.com/originals/40/e2/8f/40e28f3bca7b470044304b186a5ab1ec.jpg
//This is Timmothee Chalamet, my celebrity crush <3