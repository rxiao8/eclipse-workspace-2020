
import javax.swing.JOptionPane;

//Type in the following program on page 26 and print "Hello, your name!"
//For E.17

public class DialogViewer2 {

	public static void main(String[] args) {
		String name = JOptionPane.showInputDialog("What is your name?");
		System.out.println("Hello, Rozie");
//So this is an interaction between the user where they would have to input their name after a dialog box pops up with the question
		//what is your name. Quite interactive and a very simple base to all those other interactive pop ups or questions online
	}

}
