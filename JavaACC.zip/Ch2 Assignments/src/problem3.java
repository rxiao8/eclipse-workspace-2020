/**Rose X.
 * August 2020
 * Problem 3: User inputs first name, middle initial, and last name
 * and outputs their first initial, middle initial, and last name 
 * in lower case and w/o spacing*/

import javax.swing.JOptionPane;

public class problem3 {

	public static void main(String[] args) {
		String first = JOptionPane.showInputDialog("Enter your first name: ");
		String firstInitial = first.substring(0,1);
		String firstInitialLower = firstInitial.toLowerCase();
		
				
		String middleInitial = JOptionPane.showInputDialog("Enter your middle name's initial: \r\n(press enter if you do not have a middle name) ");
		String middleInitialLower = middleInitial.toLowerCase();
		
		
		String last = JOptionPane.showInputDialog("Enter your last name: ");
		String lastLower = last.toLowerCase();
		
		System.out.println("Output: " + firstInitialLower + middleInitialLower + lastLower);
	
	}

}
