/**Rose X.
 * August 2020
 * Problem 2: Write a program that asks the user to input a number in meters
 * and output its values in other units
Print */


import java.util.Scanner;

public class problem2{

	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		System.out.print("Enter a measurement in meters: ");
		
		double meters = in.nextDouble();
		final double numOfMillimeters = 1000; //number of mm in m
		final double numOfCentimeters = 100; //number of cm in m
		final double numOfKilometers = 0.001; //number of km in m
		final double numOfYards = 1.09361; //number of yd in m
		
		
		//the calculations
		double millimeters = meters * numOfMillimeters;
		double centimeters = meters * numOfCentimeters;
		double kilometers = meters * numOfKilometers;
		double yards = meters * numOfYards;
		
		
		//print them	
		System.out.println("Your input value: " + meters + " m "
				+ "\r\nYour value of meters in other units: ");
		
		System.out.printf("%-5s%10.3f %n", "mm:", millimeters);
		System.out.printf("%-5s%10.3f %n", "cm:", centimeters);
		System.out.printf("%-5s%10.3f %n", "km:", kilometers);
		System.out.printf("%-5s%10.3f %n", "yd:", yards);
		
		
		in.close();
			

	}

}
