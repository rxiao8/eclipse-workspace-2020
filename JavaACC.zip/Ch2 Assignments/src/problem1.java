/**Rose X.
 * August 2020
 * Problem 1: Write a program that prompts the user to enter two integers. 
 * The program will print the following results with the two integers:
 */

import java.util.Scanner;

public class problem1 {

	public static void main(String[] args) {
	
		Scanner in = new Scanner(System.in);
		
		System.out.print("Enter an integer: ");
		int valueOne = in.nextInt();
		
		System.out.print("Enter another integer: ");
		int valueTwo = in.nextInt();
		
		
		//Calculations
		int sum = valueOne + valueTwo;
		int difference = valueOne - valueTwo; 
		int product = valueOne * valueTwo;
		int average = (valueOne + valueTwo)/2;
		int distance = Math.abs(valueOne - valueTwo);
		int max = Math.max(valueOne, valueTwo);
		int min = Math.min(valueOne, valueTwo);
			
		
		//print them
		System.out.printf("Sum: %15d%n", sum);
		System.out.printf("Difference: %8d%n", difference);
		System.out.printf("Product: %11d%n", product);
		System.out.printf("Average: %11d%n", average);
		System.out.printf("Distance: %10d%n", distance);
		System.out.printf("Max: %15d%n", max);
		System.out.printf("Min: %15d%n", min);
		
		
		in.close();


	}

}
