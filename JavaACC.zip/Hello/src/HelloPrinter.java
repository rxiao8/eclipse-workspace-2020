public class HelloPrinter
{
	public static void main(String[] args)
	{
		System.out.println("Hello, World!");
		System.out.print("I'm a mess--");
		System.out.print("I'm a loser--");
		System.out.print("I'm a hater--");
		System.out.print("I'm a user--");
		System.out.print("I'm a mess for your love, it ain't new.");
	}
}

