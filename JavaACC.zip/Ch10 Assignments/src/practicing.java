import javax.swing.JFrame;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JComponent;
import javax.swing.JPanel;

public class practicing implements ActionListener {
	int count = 0;
	JFrame frame = new JFrame(); //window
	
	JButton button = new JButton("Clicker");
	
	
	JLabel label = new JLabel("number of clickds: 0");
	
	JPanel panel1 = new JPanel(); //layout
	
	public practicing() {
		
		button.addActionListener(this);
		panel1.setBorder(BorderFactory.createEmptyBorder(30, 30, 10, 30));
		panel1.setLayout(new GridLayout (0,1));
		panel1.add(button);
		label.setForeground(Color.red);
		panel1.add(label);
		frame.add(panel1, BorderLayout.CENTER);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.pack();
		frame.setVisible(true);
		
		
		
	}
	
	public void actionPerformed (ActionEvent c) {
		count++;
		label.setText("number of clicks: " + count);
	}

	public static void main(String[] args) {
		practicing one = new practicing();
		

	}

}
