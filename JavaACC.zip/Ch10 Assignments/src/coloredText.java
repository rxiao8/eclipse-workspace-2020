import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.BorderFactory;
import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class coloredText {
	private JFrame frame;
	private JPanel panelOne;
	private JPanel panelTwo;
	private JLabel message;
	private JCheckBox red;
	private JCheckBox green;
	private JCheckBox blue;
	private ActionListener listener;
	private final int FRAME_WIDTH = 650;
	private final int FRAME_HEIGHT = 120;
	private final Color VERY_LIGHT_BLUE = new Color (51, 204, 255);
	
	public coloredText() {
		frame = new JFrame();
		frame.setSize(FRAME_WIDTH, FRAME_HEIGHT);
		frame.setTitle("Color Changing Message!");
		
		createComponents();
		
		frame.add(panelOne, BorderLayout.NORTH);
		frame.add(panelTwo, BorderLayout.CENTER);
		
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setVisible(true);
	}
	
	public void createComponents() {
		panelOne = new JPanel();	
		panelTwo = new JPanel();
		panelTwo.setBorder(BorderFactory.createLoweredBevelBorder());
		panelTwo.setBackground(VERY_LIGHT_BLUE);
		
		message = new JLabel("\"We are what we repeatedly do. "
				+ "Excellence, then, is not an act, but a habit.\""
				+ "\r\n ~ Aristotle");
		red = new JCheckBox("Red");
		green = new JCheckBox("Green");
		blue = new JCheckBox("Blue");
		
		listener = new CheckboxListener();
		red.addActionListener(listener);
		green.addActionListener(listener);
		blue.addActionListener(listener);
		
		panelOne.add(red);
		panelOne.add(green);
		panelOne.add(blue);
		panelTwo.add(message);
		
	}
	
	public class CheckboxListener implements ActionListener{
		public void actionPerformed(ActionEvent event) {
	
			if (red.isSelected() && green.isSelected() && blue.isSelected()) {
				message.setForeground(Color.white);
			} 
			else if (red.isSelected()) {	
				if (green.isSelected()) {
					message.setForeground(Color.yellow);
				}
				else if (blue.isSelected()) {
					message.setForeground(Color.magenta);
				}
				else {
					message.setForeground(Color.red);
				}
				
			}
			else if (green.isSelected()) {
				if (blue.isSelected()) {
					message.setForeground(Color.cyan);
				}
				else {
					message.setForeground(Color.green);
				}
	
			}
			else if (blue.isSelected()) {
				message.setForeground(Color.blue);
				
			}
			else {
				message.setForeground(Color.black);
			}
		}
	}

	public static void main (String[] args) {
		coloredText test = new coloredText();
		
		}
	}
