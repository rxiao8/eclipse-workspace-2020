import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.BorderFactory;
import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JTextField;

public class TempConversion {
	private JFrame frame;
	private final int FRAME_WIDTH = 400;
	private final int FRAME_HEIGHT = 240;
	private JPanel panelOne;
	private JPanel panelTwo;
	private JButton convertButton;
	private JTextField inputBox;
	private JLabel inputBoxLabel;
	private int FIELD_WIDTH = 6;
	private JRadioButton celToFah;
	private JRadioButton fahToCel;
	private JPanel radioPanel;
	private ActionListener listener;
	private JLabel outputMessage;
	private JLabel outputMessageLabel;
	private double tempValue;
	private final Color GOLD = new Color (255, 204, 51);
	private final Color VERY_DARK_BLUE = new Color (0, 0, 153);
	
	public TempConversion() {
		tempValue = 0.0;
		
		frame = new JFrame();
		frame.setSize(FRAME_WIDTH, FRAME_HEIGHT);
		frame.setTitle("Temperature Converter");
		
		panelOne();
		panelTwo();
		
		frame.setLayout(new GridLayout(3, 7));
		
		frame.add(panelOne);
		frame.add(panelTwo);
		
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setVisible(true);
		
		}
	
	public void panelOne() {
		panelOne = new JPanel();
		inputBox = new JTextField(FIELD_WIDTH);
		outputMessage = new JLabel();
		
		inputBoxLabel = new JLabel("Input Temperature Value: ");
		inputBoxLabel.setForeground(VERY_DARK_BLUE);
		outputMessageLabel = new JLabel("Converted Temperature is: ");
		outputMessageLabel.setForeground(VERY_DARK_BLUE);
		
		panelOne.setLayout(new GridLayout(3, 1));
		panelOne.add(inputBoxLabel);
		panelOne.add(inputBox);
		panelOne.add(outputMessageLabel);
		panelOne.add(outputMessage);
		
	}
	
	public void panelTwo() {
		panelTwo = new JPanel();
		celToFah = new JRadioButton("Celcius to Fahrenheit");
		fahToCel = new JRadioButton("Fahrenheit to Celcius");
		
		ButtonGroup group = new ButtonGroup();
		celToFah.setSelected(true);
		group.add(celToFah);
		group.add(fahToCel);
		
		radioPanel = new JPanel();		
		radioPanel.setLayout(new GridLayout(1, 2));
		radioPanel.setBorder(BorderFactory.createLoweredBevelBorder());
		radioPanel.add(celToFah);
		radioPanel.add(fahToCel);
		
		convertButton = new JButton("Convert");
		convertButton.setBackground(GOLD);
		convertButton.setForeground(VERY_DARK_BLUE);		
		listener = new actionPerformed();
		convertButton.addActionListener(listener);

		panelTwo.setLayout(new BorderLayout());
		panelTwo.add(radioPanel, BorderLayout.NORTH);
		panelTwo.add(convertButton, BorderLayout.CENTER);
		
	}
		
	class actionPerformed implements ActionListener {

		public void actionPerformed(ActionEvent e) {
			tempValue = Double.parseDouble(inputBox.getText());
			
			if (celToFah.isSelected()) {
				tempValue = (tempValue * 9.0)/5.0 + 32;
				tempValue = Math.round(tempValue * 100.0) / 100.0;
				outputMessage.setText(tempValue + " degrees Fahrenheit");
			}
			else if (fahToCel.isSelected()) {
				tempValue = (tempValue - 32.0) * (5.0/9.0);
				tempValue = Math.round(tempValue * 100.0) / 100.0;
				outputMessage.setText(tempValue + " degrees Celcius");
			}						
		}
	}
	
	public static void main(String[] args) {
		TempConversion findCel = new TempConversion();
	} 
	
}