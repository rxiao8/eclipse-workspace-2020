//Rose X.
// September 2020
 /** Write a program prompting user to enter integer (n)
 * and will print out the sum of all even numbers (inclusive)
 * and the sum of all odd numbers (inclusive) */
import java.util.Scanner;

public class problemOne {
	public static void main(String[] args) {
	Scanner in = new Scanner(System.in);
	System.out.println("Enter an integer: ");
	int n = in.nextInt();
	int i = 0;
	int evenSum = 0;
	int oddSum = 0;
	
	for (i = 0; i <= n; i ++) {
		if (i % 2 == 0) {
			evenSum += i;
		}
		else {
			oddSum += i;
		}
	in.close();	
	}
	System.out.print(evenSum + "\r\n" + oddSum);
	
	}
	
	
}
