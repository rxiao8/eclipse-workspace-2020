//Rose X.
// September 2020
 /** the program reads a word and prints word in reverse. */
import java.util.Scanner;

public class problemThree {

	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		System.out.print("Enter a word: ");
		String word = in.next();
		
		
		for (int i = word.length(); i > 0; i --) {
			int charValue = i - 1;
			System.out.print(word.charAt(charValue));
		}
		
		in.close();

	}

}
