//Rose X.
// September 2020
 /** the program generates 10 random numbers
  * and will output the largest, smallest, and sum of the values*/

import java.util.Scanner;

public class problemTwo {

	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		System.out.println("Here is your list of numbers: ");
		double max = 0;
		double min = 0;
		double sum = 0;
		
		double num = Math.random();
		double nextNum = Math.random();
		
		if (num > nextNum) {
			max = num;
			min = nextNum;
		}
		else {
			max = nextNum;
			min = num;
		}
		
		
		System.out.printf("%.3f\r\n%.3f\r\n", num, nextNum);
		sum = sum + num + nextNum;
		
		for (int i = 0; i < 8; i ++) {
			nextNum = Math.random();
			System.out.printf("%.3f \r\n",nextNum);
			sum += nextNum;
			
			if (nextNum > max) {
				max = nextNum;
			}
			else if (nextNum < min) {
				min = nextNum;	
			}
		}
		
		System.out.printf("Max: %.3f \r\n", max);
		System.out.printf("Min: %.3f \r\n", min);
		System.out.printf("Sum: %.3f \r\n", sum);
		
		
		in.close();
			}
		
		}
	

	