import java.awt.Graphics;

//testing graphic statements


public class graphics {

	public static void draw(Graphics g) {
		int x = 0;
		int y = 0;
		final int width = 10;
		
		int i = 0;
		for (i = 0; i < 5; i ++) {
			g.drawRect(x, y, width, width);
			x = x + 2 * width;
		}

	}

}
