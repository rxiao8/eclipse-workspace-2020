//Rose X.
//August 2020
//Example 2 

public class ExampleTwo {
	public static void main(String[] args) {
		System.out.println(6+7);
		System.out.println("6+7");
		System.out.println(6+7 + " 6+7");
		System.out.println("6+7 "+ 6+7);
		System.out.println("6+7 "+ (6+7));
	}
}

//if strings come before mathematical operations, the statement will view them all as text with contenation.
//to avoid that, do math first then strings or include parentheses