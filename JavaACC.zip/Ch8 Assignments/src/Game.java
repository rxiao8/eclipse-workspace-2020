import java.util.Scanner;

/*Rose Yooo I made a tic tac toe game! XD
 * October 2020
 * Write a program that plays tic-tac-toe. The game is played on a 3x3 grid (think 2D array). The
game is played by two players, the �X� player and the �O� player. The player who goes first is the
�O� player. The player who has formed a horizontal, vertical or diagonal sequence of three
marks wins. Your program should declare a winner. You may handle the moves and display
however you wish.
You need to have at least two classes. A game class and the driver class.
The game class needs to handle the board. You are welcome to add a third
class of the player, but it is not necessary.*/
 
public class Game {
	//instance variables
	private String [][] board = new String [3] [3]; 
	private int row;
	private int column;
	private int maxTurns;
	private String letter;
	private int winner;
	private boolean endOfRound;
	
	
	
public Game() {
	for (int i = 0; i < 3; i++) {
		for (int j = 0; j < 3; j ++) {
			board[i][j] = "_";			
		}
	}
	maxTurns = 0;
	letter = " ";
	winner = 0;
}
			
public void printBoard() { 
	System.out.println(" 1 2 3");
	for (int i = 0; i < 3; i++) {
		System.out.print((i + 1) + " ");
		for (int j = 0; j < 3; j ++) {
			System.out.print(board[i][j] + " ");
		} 
		System.out.print("\r\n");
	}
	System.out.print("\r\n");
}
	
public void checking() { //grouped by connection points

	if ((board[0][0].equals(board[0][1]) && board[0][0].equals(board[0][2])) 
				
			|| (board[0][0].equals(board[1][0]) && board[0][0].equals(board[2][0]))) {
			
		letter = board[0][0]; //upper left point
	}
				
	else if ((board[1][1].equals(board[0][0]) && board[1][1].equals(board[2][2]))
				
			|| (board[1][1].equals(board[0][2]) && board[1][1].equals(board[2][0])) 
				
			|| (board[1][1].equals(board[0][1]) && board[1][1].equals(board[2][1]))
						
			|| (board[1][1].equals(board[1][0]) && board[1][1].equals(board[1][2]))){
			
		letter = board[1][1]; //middle point
	}
						
	else if ((board[2][2].equals(board[1][2]) && board[2][2].equals(board[0][2])) 
						
			|| (board[2][2].equals(board[2][1]) && board[2][2].equals(board[2][0]))) { 
			
		letter = board[2][2]; //lower right point
	}
		
		
	if (letter.equals("O")) {
		winner = 1;
	}
	else if (letter.equals("X")) {
		winner = 2;
	}		
}
	
public void printWinStatus() {
	if (winner != 0) {
		switch (winner) {
		case 1:
			System.out.println("Player One wins!");
			break;
		case 2:
			System.out.println("Player Two wins!");
			break;
		}
	}
	
	if (maxTurns > 8) {
		System.out.println("No one wins! Try another round.");
	}		
}
	
public int getWinnerNum() {
	return winner;
}
	
public int getMaxTurns() {
	return maxTurns;
}
	
public void playerOneMoves(int rowNum, int columnNum) { 
	row = rowNum - 1;
	column = columnNum - 1;
	board[row][column] = "O";
	maxTurns++;
		
	printBoard();
	checking();
}

public void playerTwoMoves(int rowNum, int columnNum) { 
	row = rowNum - 1;
	column = columnNum - 1;
	board[row][column] = "X";
	maxTurns++;
		
	printBoard();
	checking();
}
	
public void newGame() { 
	for (int i = 0; i < 3; i++) {
		for (int j = 0; j < 3; j ++) {
			board[i][j] = "_";			
		}
	}
	winner = 0;
	maxTurns = 0;
	endOfRound = false;
}
	
public boolean endOfRound() {
	if (getWinnerNum() != 0 || getMaxTurns() > 8) {
		endOfRound = true;			
	}
	return endOfRound;
}
}
	
	

	

	
		


	
