import java.util.InputMismatchException;
import java.util.Scanner;

/*Rose 
 * October 2020
 * Driver class for the Tic Tac Toe game
 */
public class driverTwo {
	public static void main(String[] args) { 
		Game first = new Game();
		Scanner in = new Scanner(System.in);
		boolean invalidInput = true;
		
		first.printBoard();
		while(true) {
			
			
			while(invalidInput) {
				try {
					in = new Scanner(System.in);
					System.out.println("Player One input your move: Row number, Enter, Column number. Enter.");
					first.playerOneMoves(in.nextInt(), in.nextInt());
					
				invalidInput = false;	
				}
				
				catch(InputMismatchException e) {
					System.out.println("Enter integers.");
				}
				catch(ArrayIndexOutOfBoundsException e) {
					System.out.println("Enter integers ranging from 1-3.");
				}
			}
			
			
			first.printWinStatus();
			if (first.endOfRound() == true) {
				in = new Scanner(System.in);
				System.out.println("Would you like to play another round? Type yes/no.");
					if (in.next().equals("no")) {
						break;
					}
					else {
						first.newGame();
						System.out.println("Player One input your move: Row number, Enter, Column number. Enter.");
						first.playerOneMoves(in.nextInt(), in.nextInt());
					
					}
			}
			
			invalidInput = true;
			
			
			
			
			while(invalidInput) {
				try {
					System.out.println("Player Two input your move: Row number, space, Column number, enter.");
					first.playerTwoMoves(in.nextInt(), in.nextInt());

				invalidInput = false;	
				}
				
				catch(InputMismatchException e) {
					System.out.println("Enter integers.");
				}
				catch(ArrayIndexOutOfBoundsException e) {
					System.out.println("Enter integers ranging from 1-3.");
				}
			}
			
			
			first.printWinStatus();
			if (first.endOfRound() == true)  {
				in = new Scanner(System.in);
				System.out.println("Would you like to play another round? Type yes/no.");
					if (in.next().equals("no")) {
						break;
					}
					else {
						first.newGame();
					
					}
			}	
			
			invalidInput = true;	
			
		
		
		}
		
		System.out.println("Thanks for playing.");
		in.close();
		
	}	
}
