/*Rose X.
 * October 2020
 * Driver class for the Student class
 */

import java.util.Scanner;

public class driverOne {

	public static void main(String[] args) { 
		Scanner in = new Scanner(System.in);
		System.out.println("Print your first name: ");
		Student sOne = new Student(in.next());

		
		boolean keepAdding = true;
		
		while (keepAdding) {
			System.out.println("Add a quiz score and hit \"1010\" to quit: ");
			int quizScore = in.nextInt();
				if (quizScore == 1010) {
					keepAdding = false;
					break;
				}
			sOne.addQuiz(quizScore);
			
		}
		
		System.out.println(sOne.getName() + " Scores "
				+ "\r\nTotal: " + sOne.getTotalScore() + 
				"\r\nAverage: " + sOne.getAverageScore());
		
	
		/*Another test
			Student sTwo = new Student("Rose");
			System.out.println(sTwo.getName());
			sTwo.addQuiz(9);
			sTwo.addQuiz(8);
			sTwo.addQuiz(7);
			System.out.println(sTwo.getTotalScore());
			System.out.println(sTwo.getAverageScore());
			*/
		
	}

}
