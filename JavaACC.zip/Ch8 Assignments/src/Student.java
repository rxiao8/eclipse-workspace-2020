/* Rose X.
 * October 2020
 * Implement a class Student. For the purpose of this exercise, a student has a name, total number
of quizzes, and total quiz score. Supply an appropriate constructor and methods: getName(),
addQuiz(int score), getTotalScore(), and getAverageScore(). 
 */
public class Student {
	private String name;
	private int numberOfQuiz;
	private int totalQuizScore;
	private double average;
	

public Student(String nameOfStudent) {
	name = nameOfStudent;
	numberOfQuiz = 0;
	totalQuizScore = 0;
	average = 0;
}
public String getName() { //getter
	return name;
	
}
public void addQuiz(int quizScore) { //setter
	numberOfQuiz++;
	totalQuizScore += quizScore;
	average = totalQuizScore/numberOfQuiz;
	
}
public int getTotalScore() { //getter
	return totalQuizScore;
	
}
public double getAverageScore() { //getter
	return average;
	
}



}


	

