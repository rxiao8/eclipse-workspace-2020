//Rose X.
//August 2020
//Problem 2
public class problem2 {
	public static void main(String[] args)
	{
		System.out.println("Hello, my name is Rose Xiao.");
		System.out.println("I am pursuing a CS degree with an interest in the cybersecurity/digital forensics field.");
		System.out.println("I do not have a favorite book/movie, but I enjoy watching forensic episodes or documentary-type videos.");
	
	}
}
