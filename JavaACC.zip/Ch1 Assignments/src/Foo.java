//Rose X.
//August 2020
//Problem 3


//Public Class Foo
//{
	//Public static void Main(string [] args)
	//{
		//System.out.println(Hi!);
		//System.out.println(5)
	//}
//}

public class Foo 
{
	public static void main(String [] args)
	{
		System.out.println("Hi!");
		System.out.println(5);
		int num1 = 10;
		   int num2 = 11;
		   int result = mystery(num1, num2);   
		System.out.print(result);
		
	}
	public static int mystery (int firstNum, int secondNum)
	{
	   firstNum = firstNum * 2;
	   secondNum = secondNum * 3;
	   return firstNum + secondNum;
	}
	
	   
	
}
