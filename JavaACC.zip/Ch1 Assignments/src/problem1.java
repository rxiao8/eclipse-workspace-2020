//Rose X.
//August 2020
//Problem 1
public class problem1 {

	public static void main(String[] args) {
		System.out.println("Hi");
		System.out.println("4");
		System.out.println(4);
		System.out.println("4" + 4);
		System.out.println(4 + 4);
		System.out.println(4 + 4 + "!");
		System.out.println("4 + 4 " + 4 + 4);
		System.out.println("4 + 4 " + (4+4));
		
	}

}
