
import java.util.Arrays;

public class testing {
	public static void main(String[] args) {
		int [] values = new int [6];
		values[0] = 4;
		values[1] = 3;
		values[2] = 19;
		values[3] = 5;
		values[4] = 16;
		values[5] = 45;
				
		
		
		int counter = 0;
		
		for (int value: values) {
			if (value != 0) {
				counter++;
			}
		}
		int [] logicalSize = Arrays.copyOf(values, counter);
		System.out.println(Arrays.toString(logicalSize));
		//probably not even have to use this ugh
		/**reverse
		int index = 0;
		int i = 0;
		int j = logicalSize.length -1;
		for (index = 0; index < logicalSize.length; index++) {
			index = logicalSize[i];
			logicalSize[i] = logicalSize[j];
			logicalSize[j] = index;
			
		}

		System.out.println(Arrays.toString(logicalSize));*/
		int [] reverse = new int [values.length];
		int i = 0;
		for (int j = values.length -1; j >= 0; j--) {
			reverse[i] = values[j];
			i++;
		}
		System.out.println(Arrays.toString(reverse));
		
		int [] revers = new int [values.length];
		   
		   int reverseOrder = values.length - 1;
		   for (int l = 0; l < revers.length; l++) {
			   revers[l] = values[reverseOrder];
			   reverseOrder--;
		   }
		   System.out.println(" " + Arrays.toString(revers));
		
		
		//compress
		int [] compressed = new int[values.length];
		int currentSize = 0;
		int yo = 0;
		for (int q = 0; q < compressed.length; q++) {
			if (yo < compressed.length -1) {
				compressed[q] = values[yo];
				yo += 2;
				currentSize++;
			}
		}
		
		compressed = Arrays.copyOf(compressed, currentSize);
		System.out.println(Arrays.toString(compressed));
		
		
		//stretch
		
		
		
		int[] stretched = new int[2 * values.length];
		int y = 0;
		for (int z = 0; z < values.length; z ++) {
			stretched[y] = values[z];
			stretched[y + 1] = values[z];
			y += 2;
		}
		
		System.out.println(Arrays.toString(stretched));
		
		
		
		//mirror
		int q = values.length - 1;
		int [] mirrorred = Arrays.copyOf(values, 2 * values.length);
		for (i = values.length; i < mirrorred.length; i ++) {
			mirrorred[i] = mirrorred[q];
			q--;
		}
		
		System.out.println(Arrays.toString(mirrorred));
		/**int INITIAL = (int) 10;
		int [] logicalSize = new int [INITIAL];
		for (counter = 0; counter < values.length && values[counter] != 0; counter++) {
			logicalSize [counter] = values[counter];
			if (counter == values.length) {
				logicalSize = Arrays.copyOf(logicalSize, 2 * logicalSize.length);
			}
			
		}
		int [] reverse = new int [logicalSize.length];
		int reverseCounter = 0;
		for (counter = logicalSize.length -1; counter > 0; counter--) {
			reverse[reverseCounter] = logicalSize[counter];
			reverseCounter++;
			
		System.out.println(reverse.toString());
		System.out.println(logicalSize.toString());
		//compress
		
	}*/
		
	}
}
	
	
