import java.util.Arrays;

/* Rose X.
 * September 2020
 * Write a method that appends one array list to another
 */

import java.util.Scanner;

public class problemOne {

	public static void main(String[] args) {
		int [] arrayA = {2, 4, 6, 8, 10};
		
		int [] arrayB = {1, 4, 7, 10, 13, 16, 19, 22};
				
		int [] arrayResult = append(arrayA, arrayB);
		
		System.out.println(Arrays.toString(arrayResult));
	
		}
	

	
	public static int[] append(int [] a, int [] b) {
		int [] newArray = Arrays.copyOf(a, a.length + b.length);
		int posForB = 0;
		for (int i = a.length; i < newArray.length; i++) {
			newArray[i] = b[posForB];
			posForB++;
		}
		
		return newArray;
	}

}
			
			
			
			


