/*Rose X.
 * October 2020
 * Input a poem file, format it into a list, and output it as a file
 */
import java.io.File;

import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.ArrayList;

import java.util.Scanner;

public class poemPrint {

	public static void main(String[] args) throws FileNotFoundException {
		
		File File = new File ("Poem.txt");
		Scanner in = new Scanner(File);
		ArrayList<String> poemArray = new ArrayList<String>();
		
		while (in.hasNext())
		{
			String value = in.nextLine();
			poemArray.add(value);
		}
		
		PrintWriter out = new PrintWriter("RevisedPoem.txt");
		for (int i = 0; i < poemArray.size(); i++) {
			int j = i + 1;
			//System.out.printf("%-4s%-50s\r\n", j + "." , poemArray.get(i));
			out.printf("%-3s%-50s\r\n", j + "." , poemArray.get(i));
		}
		
		in.close();
		out.close();
		
	}

}
