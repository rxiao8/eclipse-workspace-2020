public class apples{
public static void main(String[] args){
System.out.println("I love me some avocadoes!");
}
}