/**Rose X.
 *September 2020
 *Write a method that returns a count of all the words in a string
 *Assume all words are separated by a space. 
 */

import java.util.Scanner;

public class problemThree {

	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		System.out.println("Enter a line of text: ");
		String sentence = in.nextLine();
		
		System.out.println(wordCount(sentence));

	}
	
	public static int wordCount(String text) {
		char space = ' ';
		int wordCounter = 1;
		for (int i = 0; i < text.length(); i ++) {
			if (text.charAt(i) == space) {
				wordCounter ++;
			}
			

		
		}
		return wordCounter;
		
	}

}
