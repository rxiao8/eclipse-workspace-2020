/**Rose X.
 *September 2020
 *Write a method that returns a count of vowels in string str.
 *Include "a, e, i, o, u, y" and their upper case variants.
 */

import java.util.Scanner;

public class problemTwo {

	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		System.out.println("Enter a word: ");
		String word = in.next();
		
		int vowelCounter = vowelCounter(word);
		System.out.println("The number of vowels in the word is " + vowelCounter);
		
		in.close();
	}
	
	public static int vowelCounter (String word) {
		int i = 0;
		int totalVowels = 0;
		
		for (i = 0; i < word.length(); i ++) {
			char letter = word.charAt(i);
			if (letter == 'a' || letter == 'A' ||
					letter == 'e' || letter == 'E' ||
					letter == 'i' || letter == 'I' ||
					letter == 'o' || letter == 'O' ||
					letter == 'u' || letter == 'U' ||
					letter == 'y' || letter == 'Y') {
				totalVowels ++; 
			}
		}
		return totalVowels;
		
	}
	
	

}
