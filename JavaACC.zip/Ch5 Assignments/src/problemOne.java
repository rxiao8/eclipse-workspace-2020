/**Rose X.
 *September 2020
 *Write the three following methods and provide a
 *program to test them
 */

import java.util.Scanner;

public class problemOne {

	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		System.out.println("Enter a number: ");
		double numOne = in.nextDouble();
		System.out.println("Enter a another number: ");
		double numTwo = in.nextDouble();
		System.out.println("Enter a final number: ");
		double numThree = in.nextDouble();
		
		boolean same = allTheSame(numOne, numTwo, numThree);
		boolean different = allDifferent(numOne, numTwo, numThree);
		boolean atLeast = atLeastTwo(numOne, numTwo, numThree);
		
		System.out.println("\r\nTrue or False: ");
		System.out.println("Your inputs are all the same: " + same);
		System.out.println("Your inputs are all different: " + different);
		System.out.println("At least two of your inputs are the same: " + atLeast);
		

	}
	public static boolean allTheSame(double x, double y, double z) {
		if (x == y && y == z) {
			return true;
		}
		else {
			return false;
		}
	}
	
	public static boolean allDifferent(double x, double y, double z) {
		if (x != y && y != z && x != z) {
			return true;
		}
		else {
			return false;
		}
	}
	
	public static boolean atLeastTwo(double x, double y, double z) {
		if (x != y && y != z && x != z) {
			return false;
		}
		else {
			return true;
		}
	}
}
