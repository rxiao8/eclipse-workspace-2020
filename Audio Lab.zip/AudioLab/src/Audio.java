/**
* Audio.java, 
* Period:  
* @author ?
* @version 1.1, 10/3/2005  
*
* Class that reads, plays, determines statistics, and
* manipulates the audio from a .wav file
*/
//yoOOOOOJFeojfozjdafz
import  java.io.File;
import  java.io.IOException;
import java.util.Arrays;

import  javax.sound.sampled.AudioFormat;
import  javax.sound.sampled.AudioInputStream;
import  javax.sound.sampled.AudioSystem;
import  javax.sound.sampled.DataLine;
import  javax.sound.sampled.LineUnavailableException;
import  javax.sound.sampled.SourceDataLine;

public class Audio
{
   private String           fileName;          // .wav file name
   private AudioInputStream audioInputStream;  // stream for audio samples
   private AudioFormat      audioFormat;       // audio format info
   private SourceDataLine   line;              // object audio input/output
   private DataLine.Info    info;              // info about audio input/output
   private int              numBytes;          // number of data bytes in audio 
                                               //   array, (the logical size)
   private byte[]           audioData;         // audio array

//**
//** you must complete the following methods for Assignment 8
//**

   /**
   * Assume audioData contains numBytes of audio data
   * @return the average value in audioData   
   */
   public double sampleAverage()
   {
	  double total = 0;
      for (double element: audioData) {
    	  total += element;
      }
      
      double average = 0;
      if (audioData.length > 0) {
    	  average = total/numBytes;
 
      }
      //return 0.0;
      return average;
      
   }

   /**
   * Assume audioData contains numBytes of audio data
   * @return the standard deviation of audioData   
   */
   public double sampleStandDev()
   {
	   
	 double average = sampleAverage();
	      
     double diffTotal = 0;
     for (double element: audioData) {
    	 double difference = Math.abs(average - element);
    	 double sqrDiff = Math.pow(difference, 2);
    	 diffTotal += sqrDiff;
     }
     
     double deviation = 0;
     if (audioData.length > 0) {
    	 double variance = diffTotal/audioData.length;
    	 deviation = Math.sqrt(variance);
     }
      
     return deviation;
   }

   /**
   * Assume fileName contains name of audio file
   * @return name of the audio file   
   */  
   public String fileName()
   {

      return fileName;
      
   }

   /**
   * Assume audioData contains numBytes of audio data
   * @return the audio length in seconds   
   */
  
   public double length()
   {
	  
	   
     
	  int bytesPerFrame = audioFormat.getFrameSize();  // bytes per sample
      double sampleRate = audioFormat.getSampleRate();  // samples per second
      double seconds = numBytes * bytesPerFrame * sampleRate;
      

      return seconds;
   }

//**
//** you must complete the following methods for Assignment 8 - Part 2
//**

   /**
   * Assuming audioData contains numBytes of audio data
   * method reverses the contents of the array   
 * @return 
   */
   public byte[] reverse()
   {
      
	   
	   byte[] reversed = new byte[numBytes];
	   
	   int reverseOrder = numBytes - 1;
	   for (int i = 0; i < numBytes; i++) {
		   reversed[i] = audioData[reverseOrder];
		   reverseOrder--;
	   }
	   return reversed;
   }

     
 

   /** 
   * Assuming audioData contains numBytes of audio data
   * method removes every other sample from audioData   
 * @return 
   */
   
   public byte[] compress()
   {
      
	   
	  byte [] compressed = new byte[numBytes];
	  int currentSize = 0;
	  int afterSkip = 0;
	  for (int i = 0; i < numBytes; i++) {
		  if (afterSkip < numBytes -1) {
			  compressed[i] = audioData[afterSkip];
			  afterSkip += 2;
			  currentSize++;
		  }
	  }
		
		compressed = Arrays.copyOf(compressed, currentSize);
		return compressed;	  
   }

   /**
   * Assuming audioData contains numBytes of audio data
   * method duplicates every other sample in audioData   
 * @return 
   */ 
   public byte[] stretch()
   {
      // required for Assignment 8 - Part 2
	  byte [] stretched =new byte[2 * numBytes];
	  int index = 0;
	  for (int i = 0; i < numBytes; i ++) {
		  stretched[index] = audioData[i];
		  stretched[index + 1] = audioData[i];
		  index += 2;
	  }
	  
	  return stretched;
   }

   /** 
   * Assuming audioData contains numBytes of audio data
   * method concatenates reversed data to end of audioData   
 * @return 
   */  
   public byte[] mirror()
   {
      // required for Assignment 8 - Part 2
	   
	   	byte[] mirrored = Arrays.copyOf(audioData, 2 * numBytes);
		int index = numBytes;
		for (int i = numBytes - 1; i >= 0; i --) {
			mirrored[index] = mirrored[i];
			index ++;
		}
		
		return mirrored;
   }


//**
//** following methods are complete, DO NOT CHANGE!
//**

   /**
   * Constructor reads audio samples from .wav file and stores 
   * in audioData array
   * @param - name stores the name of a vaild .wav file,
   * @param - maxSize stores a positive integer representing
   *           max array size
   */
   public Audio(String name, int maxSize)
   {
      // set file name and create file object
      fileName         = name;
      File soundFile   = new File(fileName);

      // open audio file
      audioInputStream = null;
      try
      {
         audioInputStream = AudioSystem.getAudioInputStream(soundFile);
      }
      catch(Exception e)
      {
         e.printStackTrace();
         System.exit(1);
      }

      // read audio file format info
      audioFormat = audioInputStream.getFormat();
      line = null;
      info = new DataLine.Info(SourceDataLine.class, audioFormat);
      try
      {
         line = (SourceDataLine) AudioSystem.getLine(info);
         line.open(audioFormat);
      }
      catch(LineUnavailableException e)
      {
         e.printStackTrace();
         System.exit(1);
      }
      catch(Exception e)
      {
         e.printStackTrace();
         System.exit(1);
      }

      line.start();

      // create audio array for audio samples
      numBytes = 0;
      audioData = new byte[maxSize];

      // read audio samples
      try
      {
         numBytes = audioInputStream.read(audioData, 0, maxSize);
      }
      catch(IOException e)
      {
         e.printStackTrace();
      }
   }

   /**
   * Assuming audioData contains numBytes of audio data
   * method plays numBytes of audioData   
   * @return the number of bytes played
   */
   public int play()
   {
      int numBytesPlayed = 0;
      if(numBytes >= 0)
         numBytesPlayed = line.write(audioData, 0, numBytes);
      line.drain();
      return numBytesPlayed;
   }
   
}



