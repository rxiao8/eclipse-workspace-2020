/* Rose X.
 * September 2020
 * Write a method that appends one array list to another
 */

import java.util.ArrayList;

public class problem_One {

	public static void main(String[] args) {
		ArrayList<Integer> arrayA = new ArrayList<Integer> ();
		arrayA.add(2);
		arrayA.add(4);
		arrayA.add(6);
		
		ArrayList<Integer> arrayB = new ArrayList<Integer> ();
		arrayB.add(1);
		arrayB.add(3);
		arrayB.add(5);
		arrayB.add(7);
		arrayB.add(9);
		
		
		System.out.println(append(arrayA, arrayB));
		
		
		
		}
	public static ArrayList<Integer> append (ArrayList<Integer> a, ArrayList<Integer> b){
			
		ArrayList<Integer> comboList = new ArrayList<Integer> (a);
			
			for (int i = 0; i < b.size(); i++) {
				comboList.add(b.get(i));
			}
			return comboList;
	}

}
