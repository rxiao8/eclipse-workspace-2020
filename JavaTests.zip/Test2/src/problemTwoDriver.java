
public class problemTwoDriver {

	public static void main(String[] args) {
		Address bob = new Address();
		bob.updateMailing(23, "Willis St", "Lexington", "SC", 25558);
		String bobHouse = bob.toString();
		System.out.println(bobHouse);
		bob.getZip();
		
		Address sarah = new Address(25);
		sarah.updateMailing(50, "South Church St.", "Burlington", "SC", 27215);
		String sarahHouse = sarah.toString();
		System.out.println(bobHouse);
		sarah.getZip();
		
	}

}
