/* Rose
 * November 2020
 * Implement a class Address.  An address has a house number, a street, an optional apartment number, a city, a state, and a zip code.  

Supply two constructors: both will accept all input however, one will have an apartment number and one with not have an apartment number.  
Supply a toString method that prints the address with the street on one line and the city, state, and zip code on the next line.  
Supply a method to allow the user to update the mailing address (the house number, street, city, state, and zip).
Supply a method to get the zip code value.  

Provide a driver to test all methods.  All values can be hardcoded in (ie - you don't need to set up a Scanner - unless you want to).
 */
public class Address {
	private int houseNum;
	private String street;
	private int aptNum;
	private String city;
	private String state;
	private int zipCode;

public Address() {
	houseNum = 0;
	street = "";
	city = "";
	state = "";
	zipCode = 0;
}
public Address(int aptNum) {
	houseNum = 0;
	street = "";
	this.aptNum = 0;
	city = "";
	state = "";
	zipCode = 0;
}

public String toString() {
	return "Address: " + street + "\r\n"+ city + " " + state + " " + zipCode;
	
}

public void updateMailing(int newHouseNum, String newStreet, String newCity, String newState, int newZip) {
	houseNum = newHouseNum;
	street = newStreet;
	city = newCity;
	state = newState;
	zipCode = newZip;
}


public int getZip() {
	return  zipCode;
}
}
