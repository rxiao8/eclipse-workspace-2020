/*Rose X.
 * November 2020
 * Read in the integers from the text file (myFile.txt) located in Moodle and store it into an ArrayList.  
 * Print out the sorted array list (smallest to largest).   
 */

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Scanner;

public class NumberList {
	public static void main(String[] args) throws FileNotFoundException {
		File inputFile = new File("myFile.txt");
		Scanner in = new Scanner(inputFile);
		
		ArrayList<Integer> numberList = new ArrayList<Integer>();
		
		while (in.hasNextInt()) {
			int num = in.nextInt();
			numberList.add(num);
		}
		sortList(numberList);
	

		in.close();
	}
	
	
public static void sortList(ArrayList<Integer> list) {
		
		ArrayList<Integer> sorted = new ArrayList<Integer>();
		
		int i;
		int maxValue = 0;
		for (i = 0; i < list.size() - 1; i++) {
			int a = list.get(i);
			int b = list.get(i + 1);
			
			if (a > b && a > maxValue) {
				maxValue = a;				
			}
		}
		
		
		int j = 0;
		for (i = 0; i < list.size(); i++, j++) {
			if (j > maxValue) {
				break;
			}
		
			for (int element:list) {
				if(element == j) {
					sorted.add(i);	
				}	
			}
		}
		
		System.out.println(sorted);
	}
}
		
	

