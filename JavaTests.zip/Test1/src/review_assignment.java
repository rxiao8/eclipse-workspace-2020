//Rose X.
//September 2020
//Write a program that reads a line of text and does the following:

import java.util.Scanner;

public class review_assignment {
	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		System.out.println("Enter a line of text: ");
		String lineOfText = in.nextLine();
	
		//prints out only the upper case letters
		int i = 0;
		char space = ' ';
		char randomLower = 'a';
		
		while (i < lineOfText.length()) { 
			char c = lineOfText.charAt(i);
			
			if (c < randomLower && c != space) {
				System.out.print(c);
			}
			i ++;
			
		}
		
	
		//prints out every other letter
		for (i = 0; i < lineOfText.length(); i += 2) {
			if (lineOfText.charAt(i) == space) {
				i ++;
			}
			System.out.print(lineOfText.charAt(i));
			
			int e = i + 1; //in order to print every other word as you jump from one word to another
			if (e < lineOfText.length()) {
				if (lineOfText.charAt(e) == space) {
					i ++;
				}
			}
			
		}
		
		
	
		//replace vowels with underscores
		i = 0;
		
		while (i < lineOfText.length()) {
			char c = lineOfText.toLowerCase().charAt(i);
			
			
			if (c == 'a' || 
					c == 'e' ||
					c == 'i' ||
					c == 'o' ||
					c == 'u') {
				
					System.out.print("_");
				
			}
			else {
				c = lineOfText.charAt(i);
				System.out.print(c);
			}
			i ++;
		}
		
		
	
		//count the total time "e" appeared in the text
		i = 0;
		int eCounter = 0;
		while (i < lineOfText.length()) {
			char c = lineOfText.charAt(i);
			if (c == 'e' || c == 'E') {
				eCounter ++;
			}
			i ++;
		
		}
		System.out.println("The number of \"e's\" you have are " + eCounter); 
		in.close(); 
	
	}
}

