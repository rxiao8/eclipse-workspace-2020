/** Rose X.
 * September 2020
 * Write a program that prints out all the number
 * between 100-500 that are divisible by 5 and 6
 */
public class test1_Part2_2 {

	public static void main(String[] args) {
		
		System.out.println("Here is a list of all the numbers between 100-500 divisible by 5 and 6: ");
		
		for (int i = 100; i <= 500; i ++) {
			if (i % 5 == 0 && i % 6 == 0) {
				System.out.print(i + " ");
			}
		}
		
	}

}
