/** Rose X.
 * September 2020
 * Write a program that prints the number of vowels in a word.
 * Assume "a,e,i,o,u,& y" are vowels
 */

import java.util.Scanner;

public class test1_Part2 {

	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		System.out.print("Enter a word: ");
		String word = in.next();
		
		int i = 0;
		int totalVowels = 0;
		
		for (i = 0; i < word.length(); i ++) {
			char letter = word.toLowerCase().charAt(i);
			if (letter == 'a' ||
					letter == 'e' ||
					letter == 'i' ||
					letter == 'o' ||
					letter == 'u' ||
					letter == 'y') {
				totalVowels ++; 
			}
		}
		System.out.print("The number of vowels in " + word + " is " + totalVowels);
		in.close();
		}
	
}
