import java.util.ArrayList;
import java.util.Arrays;

/*Rose X.
 * December 2020
 * Swap first element with last element
 */
public class swapElements {

	public static void main(String[] args) {
		ArrayList<Integer> list = new ArrayList<Integer>();
		
		
		list.add(365);
		list.add(12);
		list.add(121);
		list.add(5);
		list.add(92);
		int[] numList = new int [list.size()];
		
		for (int i = 0; i < list.size(); i++) {
			numList[i] = list.get(i);
		}
		
		if (numList.length > 1) {
			int i = numList[0];
			int j = numList[numList.length-1];
			
			numList[0] = j;
			numList[numList.length-1] = i;
			
			System.out.println("Swapped first and last elements: " + Arrays.toString(numList));
			
		}
		
		
		
		

	}

}
