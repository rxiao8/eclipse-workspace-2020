/*Rose X.
 * December 2020
 * Create an interface 
 */
public interface personInterface {
	String toString();
	int getAge();
	void setAge(int a);
	String getName();
	void setName(String name);

}
