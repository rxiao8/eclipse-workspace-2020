/*Rose X.
 * December 2020
 * implement interface with additional methods
 */
public class Working implements personInterface {
	private int age;
	private String name;
	private double salary;
	private String jobTitle;
	
	public Working() {
		name = "";
		age = 0;
		jobTitle = "";
		salary = 0;
	}
	public Working(String j, int s) {
		name = "";
		age = 0;
		jobTitle = j;
		salary = s;
	}
	
	public String toString() {
		return name + " has a job title of " + jobTitle + " and earns around $" + salary;
	}
	
	public int getAge() {
		return age;
	}
	
	public void setAge(int a) {
		age = a;
	}
	
	public String getName() {
		return name;
	}
	
	public void setName(String name) {
		this.name = name;
	}
	
	public String getJobTitle() {
		return jobTitle;
	}
	
	public void setJobTitle(String j) {
		jobTitle = j;
	}
	
	
	public double getSalary() {
		return salary;
	}
	
	public void setSalary(int s) {
		salary = s;
	}
}
