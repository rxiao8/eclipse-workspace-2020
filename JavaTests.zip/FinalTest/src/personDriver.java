/*Rose X.
 * December 2020
 * create a driver for the interface
 */
public class personDriver {

	public static void main(String[] args) {
		Working one = new Working();
		one.setName("Oliver");
		one.setAge(46);
		one.setJobTitle("Vet");
		one.setSalary(93800);
		
		TrustFund t1 = new TrustFund();
		t1.setName("Maurice");
		t1.setAge(24);
		t1.setFundAmount(200000);
		t1.setSource("oil");
		
		Working two = new Working("Trial Attorneys", 101000);
		two.setName("Edward");
		two.setAge(34);
		
		System.out.println(one.toString() + "\r\nHis age: " + one.getAge());
		System.out.println(t1.toString() + "\r\nHe received around $" + t1.getFundAmount());
		
		System.out.println(two.getName());
		System.out.println(two.getJobTitle());
		

	}

}
