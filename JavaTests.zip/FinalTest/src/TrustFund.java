/*Rose X.
 * December 2020
 * implement interface with additional methods (2nd one)
 */
public class TrustFund implements personInterface {
	private String name;
	private int age;
	private double fundAmount;
	private String source;
	
	public TrustFund() {
		name = "";
		age = 0;
		fundAmount = 0;
		source = "";
		
	}
	
	public String toString() {
		return name + " who is " + age + " years old received his trust fund from " + source + ".";
	}
	
	public int getAge() {
		return age;
	}
	
	public void setAge(int a) {
		age = a;
	}
	
	public String getName() {
		return name;
	}
	
	public void setName(String name) {
		this.name = name;
	}
	
	public double getFundAmount() {
		return fundAmount;
	}
	
	public void setFundAmount(double f) {
		fundAmount = f;
		
	}
	
	public String getSource() {
		return source;
		
	}
	
	public void setSource(String s) {
		source = s;
	}
	
}
